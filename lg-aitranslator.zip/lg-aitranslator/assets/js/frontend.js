jQuery(document).ready(function($) {
    // Handle language switcher dropdown
    $('#lg-lang-select').on('change', function() {
        var lang = $(this).val();
        changeLanguage(lang);
    });

    // Handle language switcher links
    $(document).on('click', '.lg-lang-link, .lg-lang-flag-link', function(e) {
        e.preventDefault();
        var lang = $(this).data('lang');
        changeLanguage(lang);
    });

    function changeLanguage(lang) {
        // Set cookie
        document.cookie = 'lg_aitranslator_lang=' + lang + '; path=/; max-age=31536000';

        // Reload page with language parameter
        var url = new URL(window.location.href);
        url.searchParams.set('lang', lang);
        window.location.href = url.toString();
    }

    // Get current language from cookie
    function getCurrentLanguage() {
        var name = 'lg_aitranslator_lang=';
        var decodedCookie = decodeURIComponent(document.cookie);
        var ca = decodedCookie.split(';');
        for(var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') {
                c = c.substring(1);
            }
            if (c.indexOf(name) == 0) {
                return c.substring(name.length, c.length);
            }
        }
        return lgAITranslatorFrontend.defaultLang;
    }

    // Translate page content if needed
    var currentLang = getCurrentLanguage();
    var defaultLang = lgAITranslatorFrontend.defaultLang;

    if (currentLang !== defaultLang) {
        translatePage(currentLang);
    }

    function translatePage(targetLang) {
        // This is a placeholder - in production, you would implement
        // client-side translation or full page reload with translated content
        console.log('Translating page to:', targetLang);
    }
});
